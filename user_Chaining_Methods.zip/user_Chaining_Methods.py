class User:
    def __init__(self,username,email):
        self.name=username
        self.email=email
        self.account_balance=0

    def make_deposit(self, amount): #deposit money adds to account balance
        self.account_balance += amount

        return self
        
    def make_withdrawal(self, amount): #withdraw money deducts from account balance
        self.account_balance -= amount

        return self

    def display_user_balance(self):
        print("User: "+self.name+", Balance: ",self.account_balance)

    def transfer_money(self, other_user, amount):
        self.account_balance -= amount 
        # self.other_name= other_user 
        print("Other user: "+other_user+", Other balance: ",amount)
        print("User: "+self.name+", Balance: ",self.account_balance)
        
        


Glid= User("Glid Sky","GS@com")
#print('Name: '+Glid.name+',','Email: ' +Glid.email)
Marg= User("Marg","MJ@com")
#print(Marg.name)
dark= User("Dark D", "DD@com")

#Glid.make_withdrawal(50)
# print(Glid.account_balance)
Glid.make_deposit(100).make_deposit(50).make_withdrawal(200).make_deposit(10)
#print(Glid.account_balance)

Marg.make_deposit(1000).make_deposit(500).make_withdrawal(100).make_withdrawal(10)
#print(Marg.account_balance)

dark.make_deposit(200).make_withdrawal(50).make_withdrawal(100).make_withdrawal(50)
#print(dark.account_balance)

#Marg.make_deposit(1000)
print("Marg has","$",Marg.account_balance)

Glid.display_user_balance()
Marg.display_user_balance()
dark.display_user_balance()

Marg.transfer_money("Jak", 200)
